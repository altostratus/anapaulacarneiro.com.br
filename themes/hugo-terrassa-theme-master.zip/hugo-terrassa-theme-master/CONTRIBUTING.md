All contributions are welcome.

**Features**: if you are adding a feature, fork the repository, create a new branch for your feature and submit a PR. Make sure to put documentation for your new feature. If making additions that will affect the config file, make sure you update the *config.toml* on the *exampleSite*.

**Issues** or **Bugs**: submit a new issue with information about your issue or bug. If you have a solution, then submit a new PR as described above.

Thank you very much for helping to improve Terrassa.