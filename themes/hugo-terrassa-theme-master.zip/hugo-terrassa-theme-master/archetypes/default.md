---
title: "{{ replace .Name "-" " " | title }}"
description: ""
date: {{ .Date }}
publishDate: {{ .Date }}
author: "John Doe"
images: []
draft: true
tags: []
---